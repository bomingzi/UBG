#encoding:utf-8

import zmq
import struct
import enum
from typing import Optional


class MSGType(enum.Enum):
    EMPTY = 0
    QUERY_IMG = 1
    QUERY_POS = 2
    QUERY_STATUS = 3
    SEND_CTRL_CMD = 4
    EXTEND_1 = 5
    EXTEND_2 = 6
    EXTEND_3 = 7
    EXTEND_4 = 8
    EXTEND_5 = 9
    EXTEND_6 = 10
    RESPONSE = 99

MSG_MAGIC=114514

class MSG:
    msg_type:MSGType=MSGType.EMPTY
    msg_len:int=0
    msg_magic:int=MSG_MAGIC
    msg_content:bytes=b''
    
class RequestSender:
    def __init__(self,addr,port=14514):
        self._context = zmq.Context()
        self._socket = self._context.socket(zmq.REQ)
        self._socket.connect(f"tcp://{addr}:{port}")
    
    def make_request(self,message:MSG)->Optional[MSG]:
        _send=self._pack_msg(message)
        self._socket.send(_send)
        m = self._socket.recv()
        return self._unpack_msg(m)

    def _pack_msg(self,msg:MSG)->bytes:
        kformat='LLQ'
        if len(msg.msg_content)!=msg.msg_len:
            msg.msg_len=len(msg.msg_content)
        header=struct.pack(kformat,msg.msg_magic,msg.msg_type.value,msg.msg_len)
        return header+msg.msg_content

    def _unpack_msg(self,msg:bytes)->Optional[MSG]:    
        kformat='LLQ'
        size=struct.calcsize(kformat)
        if len(msg)<size:
            return None
        magic,t,l=struct.unpack(kformat,msg[:16])
        if magic!=MSG_MAGIC:
            return None
        m=MSG()
        m.msg_magic=magic
        m.msg_type=MSGType(t)
        m.msg_len=l
        m.msg_content=msg[size:]
        return m

    
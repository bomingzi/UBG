#encoding:utf-8

from typing import List, Optional
import cv2
from .jycomm import MSG,MSGType
import numpy as np

def msg_decode_as_float_vector(message:MSG)->np.ndarray:
    if message.msg_type==MSGType.EMPTY:
        return np.ndarray((0,),dtype=np.float32)
    return np.frombuffer(message.msg_content,dtype=np.float32)

def msg_decode_as_string(message:MSG)->str:
    if message.msg_type==MSGType.EMPTY:
        return ""
    return message.msg_content.decode("utf-8").strip()


def msg_decode_as_int_vector(message:MSG)->np.ndarray:
    if message.msg_type==MSGType.EMPTY:
        return np.ndarray((0,),dtype=np.int32)
    return np.frombuffer(message.msg_content,dtype=np.int32)


def msg_decode_as_image_bgr(message:MSG)->Optional[np.ndarray]:
    if message.msg_type==MSGType.EMPTY:
        return None
    try:
        content=np.frombuffer(message.msg_content,dtype=np.uint8)
        return cv2.imdecode(content,cv2.IMREAD_COLOR)
    except:
        return None

